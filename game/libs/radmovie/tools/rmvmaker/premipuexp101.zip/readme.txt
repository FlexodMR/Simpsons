<!--IPU stream exporter for Adobe Premiere --> 

Version 1.1, 9/7/2002

This archive contains a plug-in for Adobe Premiere to allow movies to be exported
in the IPU stream format (.IPU files).

Please read the enclosed document 'Using the ipu stream exporter.html'
for further details.

Changes:

Now encodes correct number of frames.
Fixes bug when encoding first line of image.
